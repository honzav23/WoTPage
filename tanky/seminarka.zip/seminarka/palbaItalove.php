<?php
$palba = array();


$palba[] = array(
 
  'sila' => '*'.$naboj1.'*'.$naboj2.'*'.$naboj3.'******
  Průbojnost:*'.$prubojnost1.' mm*'.$prubojnost2.' mm*'.$prubojnost3.' mm******
  Poškození:*'.$poskozeni1.'*'.$poskozeni2.'*'.$poskozeni3.'********
  Počet ran v zásobníku:*'.$pocetRan.'*********
  Nabíjení mezi ranami:*'.$meziNabijeni.' s********
  Čas nabití jednotlivých ran:*'.$nabijeni.'*'.$nabijeni2.'*'.$nabijeni3.'*nabijak*'.$nabijeni4.'*nabijak2*nabijak3*nabijak4
Čas zaměření:*'.$zamereni.'***zamerovak****
Přesnost:*'.$presnost.'***Presnost****',

);



function PaintTable($text) {
  
$data = explode("\n", $text);

echo '<table id="palba">';
echo '<tr><th colspan="5" id="vrsek">Palebná síla</th></tr>';
foreach ($data as $radek) {
  $bunky = explode('*', $radek);
  
 $hlas = "<tr><th>$bunky[0]</th><td id=$bunky[4]>$bunky[1]</td><td id=$bunky[6]>$bunky[2]</td><td id=$bunky[7]>$bunky[3]</td><td id=$bunky[8]>$bunky[5]</td>";
          
echo $hlas;
}

echo '</table>';
}



 
 foreach ($palba as $tank) { 
  PaintTable($tank['sila']);
  
  }
 
 
?>