<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="cs">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title>Pz.Kpfw. II Ausf. J</title>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     <script src="javascript-wotkopedie.js"></script>  <script src="zmenaDel.js"></script>
    <link rel="stylesheet" type="text/css" href="styly-wotkopedie.css">
    <?php
 $nazev = 'Pz.Kpfw. II Ausf. J';
    ?>
    
    <?php
    include 'connect.php';
    include 'dataTankAuto.php';
    include 'insert.php';
    ?>   
</head>
   <body>
   
<?php
include 'vybaveniAuto.php';
?>

    
                
             

    <h1><?php echo $nazev ?></h1>
    
   
    <p id="nabijeni"><?php echo $nabijeni?></p>
    <p id="zamerovani"><?php echo $zamereni?></p>
    <p id="presnost"><?php echo $presnost?></p>
    <p id="dohled"><?php echo $dohled?></p>
      
   <?php
 include "palbaAuto.php";
   
   
    
    
 include "mobilita.php";
   
    
    
  
 include "zbytek.php";
  
include 'vyhledavani.php';
include 'odkaz.php';
  ?>
    
 
   

  </body>
</html>
