
 
      
      function prehozeni(ukaz, schovej) {
      $('#' + ukaz).show();
      $('#' + schovej).hide();}
     
      
     var levelPosadky = 100;
     
    
    
      
      function calculateTotal() {
         var theForm = document.forms["vypocty"];
         var zakladniNabijeni = document.getElementById('nabijeni').innerHTML;
         var zakladniNabijeni2 = document.getElementById('nabijeni2').innerHTML;
         var zakladniNabijeni3 = document.getElementById('nabijeni3').innerHTML;
         var zakladniNabijeni4 = document.getElementById('nabijeni4').innerHTML;
         var ventilaceIkona = theForm.elements["cb5"];
         var bratriIkona = theForm.elements["cb6"];
    
    var nabijakIkona = theForm.elements["cb1"];
    
    var koeficientNabijeni = 1;
    var vysledek;
zmenaNabijeni();
    if (nabijakIkona.checked == true && ventilaceIkona.checked == false && bratriIkona.checked == false){
    koeficientNabijeni = 0.1;
    vysledek = (zakladniNabijeni - (zakladniNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
    vysledek2 = (zakladniNabijeni2 - (zakladniNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
    vysledek3 = (zakladniNabijeni3 - (zakladniNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
    vysledek4 = (zakladniNabijeni4 - (zakladniNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
    }
    else if (ventilaceIkona.checked == true && nabijakIkona.checked == false && bratriIkona.checked == false) {
     levelPosadky = 105.3;
     vysledek = ((zakladniNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek2 = ((zakladniNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek3 = ((zakladniNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek4 = ((zakladniNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
      }
     else if (bratriIkona.checked == true && nabijakIkona.checked == false && ventilaceIkona.checked == false) {
     levelPosadky = 105.3;
     vysledek = ((zakladniNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek2 = ((zakladniNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek3 = ((zakladniNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
     vysledek4 = ((zakladniNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
      }
      
      
      else if (nabijakIkona.checked == true && ((ventilaceIkona.checked == true && bratriIkona.checked == false) || (ventilaceIkona.checked == false && bratriIkona.checked == true))) {
       levelPosadky = 105.3;
       koeficientNabijeni = 0.1;
       var meziNabijeni = zakladniNabijeni - (zakladniNabijeni * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
       var meziNabijeni2 = zakladniNabijeni2 - (zakladniNabijeni2 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
       var meziNabijeni3 = zakladniNabijeni3 - (zakladniNabijeni3 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
       var meziNabijeni4 = zakladniNabijeni4 - (zakladniNabijeni4 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
       vysledek = ((meziNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
       vysledek2 = ((meziNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
       vysledek3 = ((meziNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
       vysledek4 = ((meziNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2); }
      
       else if (nabijakIkona.checked == false && ventilaceIkona.checked == true && bratriIkona.checked == true) {
         levelPosadky = 110.6;
         vysledek = ((zakladniNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
         vysledek2 = ((zakladniNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
         vysledek3 = ((zakladniNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
         vysledek4 = ((zakladniNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientNabijeni).toFixed(2);
       } 
       else if (nabijakIkona.checked == true && ventilaceIkona.checked == true && bratriIkona.checked == true) {
          levelPosadky = 110.6;
          koeficientNabijeni = 0.1;
          var meziNabijeni = zakladniNabijeni - (zakladniNabijeni * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
          var meziNabijeni2 = zakladniNabijeni2 - (zakladniNabijeni2 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
          var meziNabijeni3 = zakladniNabijeni3 - (zakladniNabijeni3 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
          var meziNabijeni4 = zakladniNabijeni4 - (zakladniNabijeni4 * 0.875) / (0.00375 * 100 + 0.5) * koeficientNabijeni;
       vysledek = ((meziNabijeni * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2); 
       vysledek2 = ((meziNabijeni2 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
       vysledek3 = ((meziNabijeni3 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
       vysledek4 = ((meziNabijeni4 * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);}
       else  {
          vysledek = zakladniNabijeni;
          vysledek2 = zakladniNabijeni2;
          vysledek3 = zakladniNabijeni3;
          vysledek4 = zakladniNabijeni4;
       }
       
      
     document.getElementById("nabijak").innerHTML = vysledek;
     document.getElementById("nabijak2").innerHTML = vysledek2;
     document.getElementById("nabijak3").innerHTML = vysledek3;
     document.getElementById("nabijak4").innerHTML = vysledek4;
    
    
}
 
 
 function calculateTotal1() {
    zmenaZamereni();
   var theForm = document.forms["vypocty"];
   
   var zamerovakIkona = theForm.elements["cb2"];
   var zakladniZamereni = document.getElementById('zamerovani').innerHTML;
     
     
     var ventilaceIkona = theForm.elements["cb5"];
     var bratriIkona = theForm.elements["cb6"];
     var koeficientZamereni = 1;
     var vysledek;
 
     if (zamerovakIkona.checked == true && ventilaceIkona.checked == false && bratriIkona.checked == false){
     koeficientZamereni = 0.1;
     vysledek = (zakladniZamereni - (zakladniZamereni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientZamereni).toFixed(2);
     }
     else if (ventilaceIkona.checked == true && zamerovakIkona.checked == false && bratriIkona.checked == false) {
      levelPosadky = 105.3;
      vysledek = ((zakladniZamereni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientZamereni).toFixed(2);
       }
      else if (bratriIkona.checked == true && zamerovakIkona.checked == false && ventilaceIkona.checked == false) {
      levelPosadky = 105.3;
      vysledek = ((zakladniZamereni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientZamereni).toFixed(2);
       }
       
       
       else if (zamerovakIkona.checked == true && ((ventilaceIkona.checked == true && bratriIkona.checked == false) || (ventilaceIkona.checked == false && bratriIkona.checked == true))) {
        levelPosadky = 105.3;
        koeficientZamereni = 0.1;
        var meziZamereni = zakladniZamereni - (zakladniZamereni * 0.875) / (0.00375 * 100 + 0.5) * koeficientZamereni;
        vysledek = ((meziZamereni * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2); }
       
        else if (zamerovakIkona.checked == false && ventilaceIkona.checked == true && bratriIkona.checked == true) {
          levelPosadky = 110.6;
          vysledek = ((zakladniZamereni * 0.875) / (0.00375 * levelPosadky + 0.5) * koeficientZamereni).toFixed(2);
        } 
        else if (zamerovakIkona.checked == true && ventilaceIkona.checked == true && bratriIkona.checked == true) {
           levelPosadky = 110.6;
           koeficientZamereni = 0.1;
           var meziZamereni = zakladniZamereni - (zakladniZamereni * 0.875) / (0.00375 * 100 + 0.5) * koeficientZamereni;
        vysledek = ((meziZamereni * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2); }
        else  {
           vysledek = zakladniZamereni;
        }
        
       
      document.getElementById("zamerovak").innerHTML = vysledek;
      $("#palba tr:nth-child(6) td:nth-child(2)").toggleClass("green");
 }
 
 function calculateTotal2() {
   var theForm = document.forms["vypocty"];
   zmenaDohledu();
   var optikaIkona = theForm.elements["cb3"];
   var zakladniDohled = document.getElementById('dohled').innerHTML;
   zakladniDohled = parseFloat(zakladniDohled);
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
   var koeficientDohledu = 1;
   var vysledek;
 
     if (optikaIkona.checked == true && ventilaceIkona.checked == false && bratriIkona.checked == false){
     koeficientDohledu = 0.1;
     vysledek = (zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * levelPosadky + 0.5) * koeficientDohledu).toFixed(0);
     
     }
     else if (ventilaceIkona.checked == true && optikaIkona.checked == false && bratriIkona.checked == false) {
      levelPosadky = 105.3;
      vysledek = ((zakladniDohled / 0.875) * (0.00375 * levelPosadky + 0.5) * koeficientDohledu).toFixed(0);
       }
      else if (bratriIkona.checked == true && optikaIkona.checked == false && ventilaceIkona.checked == false) {
      levelPosadky = 105.3;
      vysledek = ((zakladniDohled / 0.875) * (0.00375 * levelPosadky + 0.5) * koeficientDohledu).toFixed(0);
       }
       
       else if (optikaIkona.checked == true && ((ventilaceIkona.checked == true && bratriIkona.checked == false) || (ventilaceIkona.checked == false && bratriIkona.checked == true))) {
        levelPosadky = 105.3;
        koeficientDohledu = 0.1;
        var meziDohled = zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * 100 + 0.5) * koeficientDohledu;
        vysledek = ((meziDohled / 0.875) * (0.00375 * levelPosadky + 0.5)).toFixed(0); }
       
        else if (optikaIkona.checked == false && ventilaceIkona.checked == true && bratriIkona.checked == true) {
          levelPosadky = 110.6;
          vysledek = ((zakladniDohled / 0.875) * (0.00375 * levelPosadky + 0.5) * koeficientDohledu).toFixed(0);
        } 
        else if (optikaIkona.checked == true && ventilaceIkona.checked == true && bratriIkona.checked == true) {
           levelPosadky = 110.6;
           koeficientDohledu = 0.1;
           var meziDohled = zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * 100 + 0.5) * koeficientDohledu;
        vysledek = ((meziDohled / 0.875) * (0.00375 * levelPosadky + 0.5)).toFixed(0); }
        else  {
           vysledek = zakladniDohled;
        }
        
       
      document.getElementById("binoOp").innerHTML = vysledek;
      $("#zbytek tr:nth-child(7) td:nth-child(2)").toggleClass("green");
 }
 function calculateTotal4() {
    zmenaPresnosti();
   var theForm = document.forms["vypocty"];
   
   var zakladniPresnost = document.getElementById('presnost').innerHTML;
   zakladniPresnost = parseFloat(zakladniPresnost);
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
   
   var vysledek; 
 
     if (ventilaceIkona.checked == true && bratriIkona.checked == false) {
        levelPosadky = 105.3;
        vysledek = ((zakladniPresnost * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
     }
     else if (ventilaceIkona.checked == false && bratriIkona.checked == true) {
      levelPosadky = 105.3;
      vysledek = ((zakladniPresnost * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
     }else if (ventilaceIkona.checked == true && bratriIkona.checked == true) {
      levelPosadky = 110.6;
      vysledek = ((zakladniPresnost * 0.875) / (0.00375 * levelPosadky + 0.5)).toFixed(2);
     }
        else  {
           vysledek = zakladniPresnost;
        }
        
       
      document.getElementById("Presnost").innerHTML = vysledek;
      $("#palba tr:nth-child(7) td:nth-child(2)").toggleClass("green");
 }
 
 function calculateTotal3() {
   var theForm = document.forms["vypocty"];
  zmenaBina();
   var binoIkona = theForm.elements["cb4"];
   var zakladniDohled = document.getElementById('dohled').innerHTML;
   zakladniDohled = parseFloat(zakladniDohled);
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
   var koeficientBina = 1;
   var vysledek;
 
     if (binoIkona.checked == true && ventilaceIkona.checked == false && bratriIkona.checked == false){
     koeficientBina = 0.25;
     vysledek = (zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * levelPosadky + 0.5) * koeficientBina).toFixed(0);
     }
     
       
       else if (binoIkona.checked == true && ((ventilaceIkona.checked == true && bratriIkona.checked == false) || (ventilaceIkona4.checked == false && bratriIkona4.checked == true))) {
        levelPosadky = 105.3;
        koeficientBina = 0.25;
        var meziDohled = zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * 100 + 0.5) * koeficientBina;
        vysledek = ((meziDohled / 0.875) * (0.00375 * levelPosadky + 0.5)).toFixed(0); }
       
        
        else if (binoIkona.checked == true && ventilaceIkona.checked == true && bratriIkona.checked == true) {
           levelPosadky = 110.6;
           koeficientBina = 0.25;
           var meziDohled = zakladniDohled + (zakladniDohled / 0.875) * (0.00375 * 100 + 0.5) * koeficientBina;
        vysledek = ((meziDohled / 0.875) * (0.00375 * levelPosadky + 0.5)).toFixed(0); }
        else  {
           vysledek = zakladniDohled;
        }
        
        document.getElementById("bino").innerHTML = vysledek + " m";
        $("#zbytek tr:nth-child(8) td:nth-child(2)").toggleClass("green");
 }
 
 function zmenaNabijeni() {
   var theForm = document.forms["vypocty"];
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
var nabijeniBarva = document.getElementById("nabijak");
var nabijeniBarva2 = document.getElementById("nabijak2");
var nabijeniBarva3 = document.getElementById("nabijak3");
var nabijeniBarva4 = document.getElementById("nabijak4");
var nabijakIkona = theForm.elements["cb1"];
if ((ventilaceIkona.checked == true) || (bratriIkona.checked == true) || (nabijakIkona.checked == true)) {
   nabijeniBarva.style.backgroundColor = '#3eb943';
   nabijeniBarva2.style.backgroundColor = '#3eb943';
   nabijeniBarva3.style.backgroundColor = '#3eb943';
   nabijeniBarva4.style.backgroundColor = '#3eb943';
}
 else {nabijeniBarva.style.backgroundColor = 'inherit';
 nabijeniBarva2.style.backgroundColor = 'inherit';
 nabijeniBarva3.style.backgroundColor = 'inherit';
 nabijeniBarva4.style.backgroundColor = 'inherit';}
 }
 function zmenaZamereni() {
   var theForm = document.forms["vypocty"];
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
   var zamereniBarva = document.getElementById('zamerovak');
var zamerovakIkona = theForm.elements["cb2"];
if ((ventilaceIkona.checked == true) || (bratriIkona.checked == true) || (zamerovakIkona.checked == true)) {
   zamereniBarva.style.backgroundColor = '#3eb943';
}
 else {zamereniBarva.style.backgroundColor = 'inherit'};
 }
 function zmenaPresnosti() {
   var theForm = document.forms["vypocty"];
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
var presnostBarva = document.getElementById('Presnost');

if ((ventilaceIkona.checked == true) || (bratriIkona.checked == true) ) {
   presnostBarva.style.backgroundColor = '#3eb943';
}
 else {presnostBarva.style.backgroundColor = 'inherit'};
 }function zmenaDohledu() {
   var theForm = document.forms["vypocty"];
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
   var optikaIkona = theForm.elements["cb3"];
   var dohledBarva = document.getElementById('binoOp')

if ((ventilaceIkona.checked == true) || (bratriIkona.checked == true) || (optikaIkona.checked == true)) {
   dohledBarva.style.backgroundColor = '#3eb943';
}
 else {dohledBarva.style.backgroundColor = 'inherit';}
 }
 function zmenaBina() {
   var theForm = document.forms["vypocty"];
   var ventilaceIkona = theForm.elements["cb5"];
   var bratriIkona = theForm.elements["cb6"];
 var binoIkona = theForm.elements["cb4"];
 var binoBarva = document.getElementById('bino');


if ((ventilaceIkona.checked == true) || (bratriIkona.checked == true) || (binoIkona.checked == true)) {
   binoBarva.style.backgroundColor = '#3eb943';
}
 else {binoBarva.style.backgroundColor = 'inherit';}
 }
 
 
 
 
 
 
 

 
 
   

    

    
    
    
    



     


      
 
   

   
