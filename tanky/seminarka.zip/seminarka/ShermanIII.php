<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="cs">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title>Sherman III</title>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     <script src="javascript-wotkopedie.js"></script>  <script src="zmenaDel.js"></script>
    <link rel="stylesheet" type="text/css" href="styly-wotkopedie.css">
    <?php
 $nazev = 'Sherman III'
    ?>
    
    <?php
    include 'connect.php';
    include 'dataTank.php';
    include 'insert.php';
    ?>   
</head>
   <body>
   
<?php
include 'vybaveni.php';
?>

<form action="">
                <select id="dela" class="vyber" onchange="">
                  <option class="moznost" value="delo1">(V) 105 mm M4</option>
                   <option class="moznost" value="delo2">(VI) 76 mm Gun M1A1</option>
                </select>
                 </form>
                
             

    <h1><?php echo $nazev ?></h1>
    
   
    <p id="nabijeni"><?php echo $nabijeni?></p>
    <p id="zamerovani"><?php echo $zamereni?></p>
    <p id="presnost"><?php echo $presnost?></p>
    <p id="dohled"><?php echo $dohled?></p>
      
   <?php
 include "palba.php";
   
   
    
    
 include "mobilita.php";
   
    
    
  
 include "zbytek.php";
  
include 'vyhledavani.php';
include 'odkaz.php';
  ?>
    
    <script>
    var poskozeni1_nove = '115';
    var poskozeni1_puvod = '410';
    var poskozeni2_nove = '115';
    var poskozeni2_puvod = '350';
    var poskozeni3_nove = '185';
    var poskozeni3_puvod = 'NULL';
    var nabijeni_nove = '4.41';
    var nabijeni_puvod = '8.63';
    var zamereni_nove = '2.21';
    var zamereni_puvod = '2.4';
    var presnost_nove = '0.41';
    var presnost_puvod = '0.53';
    var naboj1_nove = 'AP';
    var naboj1_puvod = 'HE';
    var naboj2_nove = 'AP';
    var naboj2_puvod = 'HEAT';
    var naboj3_nove = 'HE';
    var naboj3_puvod = '';
    var pene1_nove = '128';
    var pene1_puvod = '53';
    var pene2_nove = '149';
    var pene2_puvod = '102';
    var pene3_nove = '38';
    var pene3_puvod = 'NULL';
    var nazev = "Sherman III";
    
  
   
    </script>
   

  </body>
</html>
