<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="cs">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title>T49</title>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     <script src="javascript-wotkopedie.js"></script>  <script src="zmenaDel.js"></script>
    <link rel="stylesheet" type="text/css" href="styly-wotkopedie.css">
    <?php
 $nazev = 'T49';
    ?>
    
    <?php
    include 'connect.php';
    include 'dataTank.php';
    include 'insert.php';
    ?>   
</head>
   <body>
   
<?php
include 'vybaveni.php';
?>

<form action="">
                <select id="dela" class="vyber" onchange="">
                  <option class="moznost" value="delo1">(IX) 90 mm Gun T132E3</option>
                   <option class="moznost" value="delo2">(X) 152 mm XM81</option>
                </select>
                 </form>
                
             

    <h1><?php echo $nazev ?></h1>
    
   
    <p id="nabijeni"><?php echo $nabijeni?></p>
    <p id="zamerovani"><?php echo $zamereni?></p>
    <p id="presnost"><?php echo $presnost?></p>
    <p id="dohled"><?php echo $dohled?></p>
      
   <?php
 include "palba.php";
   
   
    
    
 include "mobilita.php";
   
    
    
  
 include "zbytek.php";
  
include 'vyhledavani.php';
include 'odkaz.php';
  ?>
    
 
    <script>
    var poskozeni1_nove = '910';
    var poskozeni1_puvod = '240';
    var poskozeni2_nove = '700';
    var poskozeni2_puvod = '240';
    var poskozeni3_nove = '910';
    var poskozeni3_puvod = '320';
    var nabijeni_nove = '22.05';
    var nabijeni_puvod = '5.75';
    var zamereni_nove = '3.45';
    var zamereni_puvod = '2.21';
    var presnost_nove = '0.58';
    var presnost_puvod = '0.38';
    var naboj1_nove = 'HE';
    var naboj1_puvod = 'APCR';
    var naboj2_nove = 'HEAT';
    var naboj2_puvod = 'HEAT';
    var naboj3_nove = 'HE';
    var naboj3_puvod = 'HE';
    var pene1_nove = '76';
    var pene1_puvod = '212';
    var pene2_nove = '152';
    var pene2_puvod = '250';
    var pene3_nove = '85';
    var pene3_puvod = '45';
    var nazev = "T49";
    
  
   
    </script>

  </body>
</html>
