<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="cs">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title>XM551 Sheridan</title>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     <script src="javascript-wotkopedie.js"></script>  <script src="zmenaDel.js"></script>
    <link rel="stylesheet" type="text/css" href="styly-wotkopedie.css">
    <?php
 $nazev = 'XM551 Sheridan';
    ?>
    
    <?php
    include 'connect.php';
    include 'dataTank.php';
    include 'insert.php';
    ?>   
</head>
   <body>
   
<?php
include 'vybaveni.php';
?>

    
<form action="">
                <select id="dela" class="vyber" onchange="">
                  <option class="moznost" value="delo1">(IX) 105 mm Ltwt. Gun</option>
                   <option class="moznost" value="delo2">(X) 152 mm XM81</option>
                </select>
                 </form>        
             

    <h1><?php echo $nazev ?></h1>
    
   
    <p id="nabijeni"><?php echo $nabijeni?></p>
    <p id="zamerovani"><?php echo $zamereni?></p>
    <p id="presnost"><?php echo $presnost?></p>
    <p id="dohled"><?php echo $dohled?></p>
      
   <?php
 include "palba.php";
   
   
    
    
 include "mobilita.php";
   
    
    
  
 include "zbytek.php";
  
include 'vyhledavani.php';
include 'odkaz.php';
  ?>
    
 
    <script>
    var poskozeni1_nove = '910';
    var poskozeni1_puvod = '390';
    var poskozeni2_nove = '700';
    var poskozeni2_puvod = '390';
    var poskozeni3_nove = '910';
    var poskozeni3_puvod = '480';
    var nabijeni_nove = '19.18';
    var nabijeni_puvod = '8.82';
    var zamereni_nove = '3.16';
    var zamereni_puvod = '1.63';
    var presnost_nove = '0.51';
    var presnost_puvod = '0.38';
    var naboj1_nove = 'HE';
    var naboj1_puvod = 'APCR';
    var naboj2_nove = 'HEAT';
    var naboj2_puvod = 'HEAT';
    var naboj3_nove = 'HE';
    var naboj3_puvod = 'HE';
    var pene1_nove = '76';
    var pene1_puvod = '236';
    var pene2_nove = '152';
    var pene2_puvod = '280';
    var pene3_nove = '85';
    var pene3_puvod = '53';
    var nazev = "XM551 Sheridan";
    
  
   
    </script>


  </body>
</html>
