<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="cs">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title>Progetto M40 mod. 65</title>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     <script src="italove.js"></script>  <script src="zmenaDel.js"></script>
    <link rel="stylesheet" type="text/css" href="styly-wotkopedie.css">
    <?php
 $nazev = 'Progetto M40 mod. 65';
    ?>
    
    <?php
    include 'connect.php';
    include 'dataTank.php';
   
    ?> 
    
</head>
   <body>
   
<?php
include 'vybaveniItalove.php';
?>

    
                
             

    <h1><?php echo $nazev ?></h1>
     <p id="nabijeni"><?php echo $nabijeni?></p>
     <p id="nabijeni2"><?php echo $nabijeni2?></p>
     <p id="nabijeni3"><?php echo $nabijeni3?></p>
     <p id="nabijeni4"><?php echo $nabijeni4?></p>
    <p id="zamerovani"><?php echo $zamereni?></p>
    <p id="presnost"><?php echo $presnost?></p>
    <p id="dohled"><?php echo $dohled?></p>
      
   <?php
 include "palbaItalove.php";
   
   
    
    
 include "mobilita.php";
   
    
    
  
 include "zbytek.php";
  
include 'vyhledavani.php';
include 'odkaz.php';
  ?>
    
 
   

  </body>
</html>
